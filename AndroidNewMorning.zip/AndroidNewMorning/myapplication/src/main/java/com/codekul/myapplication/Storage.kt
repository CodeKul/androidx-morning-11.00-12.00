package com.codekul.myapplication

import android.app.Activity
import android.os.Bundle

class Storage : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_storage)
    }
}
