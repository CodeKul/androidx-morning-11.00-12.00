package com.codekul.storage

class MySqlite {


    fun selectAllPhotos() {

    }
}